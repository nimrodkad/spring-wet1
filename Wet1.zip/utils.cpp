#include "utils.h"

int maxInt(int a, int b) { return (a > b) ? a : b; }

