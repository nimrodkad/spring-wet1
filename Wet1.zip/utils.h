#ifndef UTILS_H
#define UTILS_H

//maxInt function: returns the bigger int number between two integers.
int maxInt(int a, int b);


#endif /* UTILS_H */
